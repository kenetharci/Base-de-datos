import mysql.connector
from pymongo import MongoClient
import time

# Configuración de MySQL
mysql_config = {
    'host': 'localhost',
    'user': 'root',  # Usuario de MySQL
    'password': '12345',  # Contraseña de MySQL
    'database': 'gestioncompras',  # Nombre de la base de datos
}

# Conexión a MySQL
def connect_mysql():
    return mysql.connector.connect(**mysql_config)

# Conexión a MongoDB
def connect_mongo():
    client = MongoClient('mongodb+srv://root:Alexander1405@cluster0.zulbp.mongodb.net/')  # Cambia la URL si es necesario
    db = client['GestionCompras']  # Nombre de la base de datos en MongoDB
    return db

# Función para obtener los datos de MySQL
def get_mysql_data():
    conn = connect_mysql()
    cursor = conn.cursor(dictionary=True)

    # Obtener datos de la tabla Clientes
    cursor.execute("SELECT * FROM Clientes")
    clientes = cursor.fetchall()

    # Obtener datos de la tabla Productos
    cursor.execute("SELECT * FROM Productos")
    productos = cursor.fetchall()

    # Obtener datos de la tabla Compras
    cursor.execute("SELECT * FROM Compras")
    compras = cursor.fetchall()

    # Obtener datos de la tabla DetallesCompra
    cursor.execute("SELECT * FROM DetallesCompra")
    detalles_compra = cursor.fetchall()

    # Obtener datos de la tabla Devoluciones
    cursor.execute("SELECT * FROM Devoluciones")
    devoluciones = cursor.fetchall()

    # Obtener datos de la tabla Sucursales
    cursor.execute("SELECT * FROM Sucursales")
    sucursales = cursor.fetchall()

    # Obtener datos de la tabla ServicioAlCliente
    cursor.execute("SELECT * FROM ServicioAlCliente")
    servicio_al_cliente = cursor.fetchall()

    conn.close()
    return {
        "clientes": clientes,
        "productos": productos,
        "compras": compras,
        "detalles_compra": detalles_compra,
        "devoluciones": devoluciones,
        "sucursales": sucursales,
        "servicio_al_cliente": servicio_al_cliente
    }

# Función para insertar datos en MongoDB
def insert_into_mongo(data):
    db = connect_mongo()
    
    # Insertar clientes
    db.clientes.insert_many(data['clientes'])
    
    # Insertar productos
    db.productos.insert_many(data['productos'])
    
    # Insertar compras
    db.compras.insert_many(data['compras'])
    
    # Insertar detalles de compra
    db.detalles_compra.insert_many(data['detalles_compra'])
    
    # Insertar devoluciones
    db.devoluciones.insert_many(data['devoluciones'])
    
    # Insertar sucursales
    db.sucursales.insert_many(data['sucursales'])
    
    # Insertar servicio al cliente
    db.servicio_al_cliente.insert_many(data['servicio_al_cliente'])

# Función para limpiar la base de datos en MongoDB
def clear_mongo_db():
    db = connect_mongo()
    
    # Eliminar las colecciones después de insertar los datos
    db.clientes.drop()
    db.productos.drop()
    db.compras.drop()
    db.detalles_compra.drop()
    db.devoluciones.drop()
    db.sucursales.drop()
    db.servicio_al_cliente.drop()

# Función principal que se ejecuta cada 10 segundos
def sync_data():
    while True:
        print("Obteniendo datos de MySQL...")
        data = get_mysql_data()  # Obtener datos de MySQL
        print("Insertando datos en MongoDB...")
        clear_mongo_db()  # Limpiar la base de datos en MongoDB
        insert_into_mongo(data)  # Insertar datos en MongoDB
        print("Datos transferidos y base de datos limpiada.")
        time.sleep(10)  # Esperar 10 segundos

if __name__ == "__main__":
    sync_data()
