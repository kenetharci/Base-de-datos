from flask import Flask, render_template, request, redirect, session, url_for, flash
import pymysql
import bcrypt
import secrets  # Se importa el módulo secrets para la clave secreta
import mysql.connector
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)

# Establecer una clave secreta para la sesión
app.secret_key = secrets.token_hex(16)  # Genera una clave secreta de 16 bytes

# Configuración de la base de datos
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '12345',
    'database': 'gestioncompras'
}

# Variable para rastrear si se realizó la inicialización
initialized = False

@app.before_request
def initialize_database():
    global initialized
    if not initialized:
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                usuario VARCHAR(50) UNIQUE NOT NULL,
                contrasena VARCHAR(255) NOT NULL,
                tipo_cuenta ENUM('Administrador', 'Usuario') NOT NULL
            )
        """)
        conn.commit()

        # Insertar datos de prueba si no existen
        cursor.execute("SELECT COUNT(*) FROM usuarios")
        count = cursor.fetchone()[0]
        if count == 0:
            cursor.execute("INSERT INTO usuarios (usuario, contrasena, tipo_cuenta) VALUES (%s, %s, %s)",
                           ('admin', bcrypt.hashpw('Santi2014'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'), 'Administrador'))
            cursor.execute("INSERT INTO usuarios (usuario, contrasena, tipo_cuenta) VALUES (%s, %s, %s)",
                           ('user', bcrypt.hashpw('Alexander1405'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'), 'Usuario'))
            conn.commit()

        cursor.close()
        conn.close()
        initialized = True

@app.route('/')
def home():
    return render_template('index3.html')

@app.route('/productos')
def productos():
    return render_template('productos.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        usuario = request.form['usuario']
        contrasena = request.form['contrasena']
        
        # Encriptar la contraseña
        hashed_contrasena = bcrypt.hashpw(contrasena.encode('utf-8'), bcrypt.gensalt())

        # Verificar si el usuario ya existe
        try:
            conn = pymysql.connect(**db_config)
            cursor = conn.cursor()

            # Verificar si el correo electrónico ya está registrado
            cursor.execute("SELECT usuario FROM usuarios WHERE usuario = %s", (usuario,))
            if cursor.fetchone():
                flash("El correo electrónico ya está registrado.", 'error')
                return redirect(url_for('register'))

            # Determinar el tipo de cuenta basado en el dominio del correo electrónico
            tipo_cuenta = 'Administrador' if '@techstore.com' in usuario else 'Usuario'

            # Insertar el nuevo usuario en la base de datos
            cursor.execute(
                "INSERT INTO usuarios (usuario, contrasena, tipo_cuenta) VALUES (%s, %s, %s)",
                (usuario, hashed_contrasena, tipo_cuenta)
            )
            conn.commit()

            flash("Registro exitoso. Ahora puedes iniciar sesión.", 'success')
            return redirect(url_for('login'))

        except pymysql.MySQLError as e:
            flash(f"Error de conexión con la base de datos: {e}", 'error')
        finally:
            cursor.close()
            conn.close()

    return render_template('register.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        contrasena = request.form['contrasena']

        try:
            # Conectar a la base de datos
            conn = pymysql.connect(**db_config)
            cursor = conn.cursor()

            cursor.execute("SELECT id, contrasena, tipo_cuenta FROM usuarios WHERE usuario = %s", (usuario,))
            user_data = cursor.fetchone()

            cursor.close()
            conn.close()

            if user_data:
                user_dict = {
                    'id': user_data[0],
                    'contrasena': user_data[1],
                    'tipo_cuenta': user_data[2]
                }

                # Verificar la contraseña
                if bcrypt.checkpw(contrasena.encode('utf-8'), user_dict['contrasena'].encode('utf-8')):
                    session['usuario'] = usuario
                    session['tipo_cuenta'] = user_dict['tipo_cuenta']
                    session['usuario_id'] = user_dict['id']  # Asegúrate de guardar el ID del usuario

                    # Redirigir a la función registrar_cliente
                    return redirect(url_for('registrar_cliente'))
                else:
                    flash("Contraseña incorrecta.", 'error')
            else:
                flash("Usuario no encontrado.", 'error')

        except pymysql.MySQLError as e:
            flash(f"Error de conexión con la base de datos: {e}", 'error')

    return render_template('login.html')


@app.route('/administrador')
def administrador():
    if 'usuario' in session and session['tipo_cuenta'] == 'Administrador':
        return render_template('admin.html')
    return redirect(url_for('home'))

@app.route('/usuario')
def usuario():
    if 'usuario' in session and session['tipo_cuenta'] == 'Usuario':
        return render_template('usuario.html')
    return redirect(url_for('home'))  

@app.route('/ubicacion-sucursales')
def ubicacion_sucursales():
    return render_template('ubicacion-sucursales.html')

@app.route('/gestiondevoluciones')
def gestiondevoluciones():
    return render_template('gestiondevoluciones.html')

@app.route('/gestioncompras')
def gestioncompras():
    conn = pymysql.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    # Obtener todas las compras con sus detalles
    cursor.execute("""
        SELECT c.id_compra, c.fecha, c.total, cl.nombre AS cliente
        FROM Compras c
        JOIN Clientes cl ON c.id_cliente = cl.id_cliente
    """)

    compras = cursor.fetchall()

    # Obtener detalles de cada compra
    for compra in compras:
        cursor.execute("SELECT * FROM DetallesCompra WHERE id_compra = %s", (compra['id_compra'],))
        compra['detalles'] = cursor.fetchall()  # Agregar detalles a cada compra

    cursor.close()
    conn.close()

    return render_template('gestioncompras.html', compras=compras)

@app.route('/contacto')
def contacto():
    return render_template('contacto.html')

@app.route('/servicioalcliente')
def servicio_al_cliente():
    return render_template('servicioalcliente.html')

@app.route('/adminservicioalcliente')
def admin_servicio_al_cliente():
    if 'usuario' in session and session['tipo_cuenta'] == 'Administrador':
        return render_template('adminservicioalcliente.html')
    return redirect(url_for('home'))

@app.route('/comentariosycalificaciones')
def comentariosycalificaciones():
    return render_template('comentariosycalificaciones.html')

@app.route('/productosusuarios1')
def productosusuarios1():
    return render_template('productosusuarios1.html')  # Cambia 'productos1.html' al nombre adecuado de tu plantilla

@app.route('/logout')
def logout():
    session.pop('usuario', None)
    session.pop('tipo_cuenta', None)
    return redirect(url_for('home'))

@app.route('/procesar_compra', methods=['POST'])
def procesar_compra():
    if 'usuario_id' not in session:
        flash("Debes iniciar sesión para realizar una compra.")
        return redirect(url_for('home'))  # Redirige al inicio si no hay sesión activa

    conn = None  # Inicializar conn antes de la sección try
    try:
        # Recoge los datos del formulario
        id_producto = request.form['id_producto']  # ID del producto
        precio = float(request.form['precio'])  # Asegúrate de convertir el precio a flotante
        cantidad = int(request.form['cantidad'])  # Asegúrate de convertir la cantidad a entero
        direccion = request.form.get('ubicacion', 'Sin dirección especificada')  # Dirección opcional

        total = precio * cantidad  # Calcula el total

        # Establecer la conexión a la base de datos
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()

        # Insertar en la tabla Compras con los datos correctos
        cursor.execute("""
            INSERT INTO Compras (id_cliente, id_producto, total, ubicacion)
            VALUES (%s, %s, %s, %s)
        """, (session.get('usuario_id'), id_producto, total, direccion))
        conn.commit()

        flash("Compra realizada con éxito.")
    except Exception as e:
        flash(f"Ocurrió un error al procesar la compra: {e}")
    finally:
        if conn:
            conn.close()

    return redirect(url_for('comprasusuarios'))  # Redirige al historial de compras


@app.route('/compra_exitosa')
def compra_exitosa():
    return render_template('compra_exitosa.html')


@app.route('/comprasusuarios', methods=['GET', 'POST'])
def comprasusuarios():
    if request.method == 'POST':
        # Obtener el ID del cliente desde la sesión
        id_cliente = session.get('usuario_id')  # Asegúrate de que el ID del cliente esté en la sesión

        if not id_cliente:
            flash('Debe iniciar sesión para realizar una compra', 'error')
            return redirect(url_for('login'))  # Redirigir al login si no hay sesión activa

        # Obtener los datos del formulario
        total = request.form['total']
        direccion = request.form['direccion']

        # Conectar con la base de datos
        conn = None  # Inicializamos la variable conn
        try:
            conn = pymysql.connect(**db_config)
            cursor = conn.cursor()

            # Insertar la nueva compra en la base de datos
            cursor.execute("INSERT INTO Compras (id_cliente, total, ubicacion) VALUES (%s, %s, %s)",
                           (id_cliente, total, direccion))
            conn.commit()

            flash('Compra realizada exitosamente!', 'success')  # Mensaje flash
            return redirect(url_for('usuario'))  # Redirige a usuario.html
        except Exception as e:
            if conn:
                conn.rollback()  # Hacer rollback en caso de error
            flash(f'Hubo un error al realizar la compra: {e}', 'error')  # Mensaje de error
            return redirect(url_for('productosusuarios1'))  # Redirigir a productos en caso de error
        finally:
            if conn:
                cursor.close()
                conn.close()

    # Si es GET, solo se muestra la página
    total = request.args.get('total', type=float)  # Obtener el total desde los parámetros de la URL
    return render_template('comprasusuarios.html', total=total)


@app.route('/registro_cliente', methods=['GET', 'POST'])
def registrar_cliente():
    if request.method == 'POST':
        # Obtener los datos del formulario
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        telefono = request.form.get('telefono')
        direccion = request.form.get('direccion')

        # Depuración: Verificar los datos recibidos
        print(f"Datos recibidos: {nombre}, {email}, {telefono}, {direccion}")

        try:
            # Conectar a la base de datos
            conn = pymysql.connect(**db_config)
            cursor = conn.cursor()

            # Verificar la conexión
            print("Conexión a la base de datos establecida.")
            
            # Insertar cliente en la base de datos
            query = """INSERT INTO Clientes (nombre, email, telefono, direccion) 
                       VALUES (%s, %s, %s, %s)"""
            cursor.execute(query, (nombre, email, telefono, direccion))

            conn.commit()

            # Verificar si se insertaron los datos correctamente
            print(f"Cliente {nombre} registrado con éxito.")
            
            flash('Cliente registrado correctamente', 'success')
            return redirect(url_for('usuario'))  # Redirigir al usuario a la página 'usuario'

        except Exception as e:
            flash(f'Error: {e}', 'error')
            print(f"Error al registrar cliente: {e}")

    return render_template('registroclientes.html')
 # Asegúrate de que este archivo esté en la carpeta templates


# Función para obtener la conexión a la base de datos.
def get_db_connection():
    conn = pymysql.connect(**db_config)
    return conn

if __name__ == '__main__':
    app.run(debug=True)
